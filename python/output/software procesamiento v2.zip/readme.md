INSTRUCCIONES:

- Todos los archivos descomprimidos deben encontrarse en la misma carpeta
  |-> main.exe (archivo principal para la ejecución del programa)
  |-> dji_therman_sdk (carpeta que contiene ejecutables y DDL de las librerías utilizadas)
  |-> Térmicas (carpeta que contiene las imagénes térmicas a procesar)

- Ejecutar el archivo main.py
- Esperar a la ejecución del programa (ver mensajes en consola que muestran los pasos de ejecución)
- Al finalizar se habrán creado múltiples carpetas con imágenes que son el resultado de la ejecución.